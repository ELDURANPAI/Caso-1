/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package caso1;

import javax.swing.JOptionPane;


/**
 *
 * @author LABORATORIO 04
 */
public class Caso1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        //Importar la clase factura:
        factura Factura1 = new factura();
     
        //crear ciclo while:
        while(true){
            
            
            //Imprimir Menú y solicitar opción:
            int opcionMenu = Integer.parseInt(JOptionPane.showInputDialog("1. Crear Factura. \n2. Mostrar Facturas. \n3. Mostrar Cuotas. \n4.Salir. \n\nSeleccione una opcion:"));

            //Si se seleccionó la opción 1:
            switch (opcionMenu) {
                case 1:
                    Factura1.SolicitarDatos();
                    break;
                case 2:
                    Factura1.ImprimirDatos();
                    break;
                case 3:
                    Factura1.CuotasMensuales();
                    break;
                case 4:
                    System.exit (1);
                default:
                    JOptionPane.showMessageDialog(null, "¡Por favor, ingrese una opción válida!");
                    break;
            }
            
        }
        
        
        
    }
    
}
