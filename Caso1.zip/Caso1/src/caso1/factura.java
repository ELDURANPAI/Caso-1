/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package caso1;

import javax.swing.JOptionPane;

/**
 *
 * @author LABORATORIO 04
 */
public class factura {
    
    //declarar variables a usar para la creación de una factura:
    
    public String nombre = "";
    public int cedula = 0;
    public int numeroFactura = 0;
    public float montoFactura = 0;
    public String mes = "";
    public String anio = "";
    public String estadoFactura = "";
    public float cuotaMensual = 0;
    public String cuota = "";
    
    public void SolicitarDatos(){
        
        //Solicitar los datos de la factura:
        
        nombre = JOptionPane.showInputDialog("Digite el nombre del cliente: ");
        cedula = Integer.parseInt(JOptionPane.showInputDialog("Digite el número de cédula del cliente: "));
        numeroFactura = Integer.parseInt(JOptionPane.showInputDialog("Asigne un número de factura: "));
        montoFactura = Integer.parseInt(JOptionPane.showInputDialog("Digite el monto de la factura: "));
        mes = JOptionPane.showInputDialog("Escriba el mes en el que se está realizando la factura: ");
        anio = JOptionPane.showInputDialog("Escriba el año en el que se está realizando la factura: ");
        estadoFactura = JOptionPane.showInputDialog("NO pagada (2) - PAGADA (1) \nIngrese el estado de la factura: ");
        
    }
    
    public void ImprimirDatos(){
        
        //Imprimimos todos los datos solicitados en el apartado de "SolicitarDatos"
        JOptionPane.showMessageDialog(null, "Cliente: "+nombre+"\nCédula: "+cedula+"\nNúmero de factura: "+numeroFactura+"\nMonto de la factura: "+montoFactura+"\nMes: "+mes+"\nAño: "+anio+"\nEstado de la factura: "+estadoFactura);
    
        
    }
    
    public void CuotasMensuales(){

        //realizar la operación de las cuotas:
        cuotaMensual = (float) (((montoFactura*0.05)+montoFactura)/6);
        
        JOptionPane.showMessageDialog(null, "Meses de pago: Julio, Agosto, Setiembre, Octubre, Noviembre, Diciembre. \n\nCuota mensual: "+cuotaMensual);
       
    }
}
